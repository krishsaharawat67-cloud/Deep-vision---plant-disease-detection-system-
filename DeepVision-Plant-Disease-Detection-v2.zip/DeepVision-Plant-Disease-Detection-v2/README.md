# DeepVision – Plant Disease Detection System

A Deep Learning project that classifies plant leaf images into disease/healthy categories using Convolutional Neural Networks (CNN) and Transfer Learning.

## Features
- Image preprocessing and augmentation
- Transfer learning with MobileNetV2
- Multi-class plant disease classification
- Accuracy/loss visualization
- Confusion matrix and classification report
- Streamlit web interface
- Single-image prediction with confidence score
- GitHub-ready project structure

## Dataset
Recommended dataset: PlantVillage. Download it separately and arrange class folders under `dataset/train`, `dataset/validation`, and `dataset/test`.

Example:
```
dataset/
├── train/
│   ├── Tomato___healthy/
│   ├── Tomato___Early_blight/
│   └── ...
├── validation/
└── test/
```

## Installation
```bash
python -m venv venv
# Windows: venv\Scripts\activate
# Linux/macOS: source venv/bin/activate
pip install -r requirements.txt
```

## Training
```bash
python train.py
```

The trained model is saved as:
`models/plant_disease_model.keras`

## Run the application
```bash
streamlit run app.py
```

## Project Workflow
Image → Resize/Normalize → Data Augmentation → MobileNetV2 Feature Extraction → Dense Classifier → Disease Prediction → Confidence

## Evaluation
The training script generates:
- results/accuracy.png
- results/loss.png
- results/confusion_matrix.png
- results/classification_report.txt

## Important
The repository intentionally does not include a large dataset or trained weights. Add your dataset locally, train the model, and upload the resulting model only if repository-size limits allow it.

## Course
B.Tech CSE (AI-ML)
